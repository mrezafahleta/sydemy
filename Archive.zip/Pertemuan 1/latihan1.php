<?php
class Kampus{


}
$datamahasiswa = new Kampus();
var_dump($datamahasiswa);